import codecs
import pickle
import os
from collections import Counter
from tkinter import *
from tkinter.filedialog import askopenfilename, askdirectory
from tkinter.messagebox import showerror
from tkinter.messagebox import showinfo


class MyFrame(Frame):
    def __init__(self):
        Frame.__init__(self)
        self.master.title("Importer")
        self.master.rowconfigure(5, weight=1)
        self.master.columnconfigure(5, weight=1)
        self.grid(sticky=W+E+N+S)

        self.fname=askdirectory()
        print (self.fname)
        self.load_file()
        #self.button = command(self, self.load_file)
        #self.button.grid(row=1, column=0, sticky=W)
        #self.button = Button(self, text="Browse", command=self.load_file, width=10)
        #self.button.grid(row=1, column=0, sticky=W)

    def load_file(self):
        #self.fname = askopenfilename(filetypes=(("All files", "*.*"),
                                       #    ("All files", "*.*") ))
        
        if self.fname:
            try:
                print(self.fname)
                self.master.destroy()
            except:                     # <- naked except is a bad idea
                showerror("Open Source File", "Failed to read file\n'%s'" % self.fname)
            return self.fname
        
        
showinfo(
            "Open Directory",
            "Please select the Spam email folder"
        )
if __name__ == "__main__":
    test =MyFrame()
    test.mainloop()


pathsp = test.fname

print(pathsp)

showinfo(
            "Open Directory",
            "Please select the ham email folder")

if __name__ == "__main__":
    test =MyFrame()
    test.mainloop()

pathhm= test.fname
print(pathhm)

def split_list(list_name):
    half = len(list_name)/2
    half = round(half)
    return list_name[:half], list_name[half:]

path=pathsp
spam = []
for n3xt in os.listdir(path):
    with open(path+'\\'+n3xt, 'r', encoding='utf-8',errors='ignore') as text:
        #print (n3xt)
        var = text.read()
        #print (var)
        spam.append(var)

print (spam[1])

path=pathhm
ham = []
for n4xt in os.listdir(path):
    with open(path+'\\'+n4xt, 'r', encoding='utf-8',errors='ignore') as text:
        #print (n4xt)
        var = text.read()
        #print (var)
        ham.append(var)

print (ham[5])


spam1,spam2 = split_list(spam)

#for message in spam1:
#    print(message)
#
#for message in spam2:
#    print(message)


ham1,ham2 = split_list(ham)



# store spam & ham in file to decrease running time

pickle.dump(spam1, open('spam1.bin', 'wb'))

pickle.dump(spam1, open('spam2.bin', 'wb'))            
            
pickle.dump(ham1, open('ham1.bin', 'wb'))
            
pickle.dump(ham2, open('ham2.bin', 'wb'))
            



#for message in ham1:
#    print(message)
#
#for message in ham2:
#    print(message)





